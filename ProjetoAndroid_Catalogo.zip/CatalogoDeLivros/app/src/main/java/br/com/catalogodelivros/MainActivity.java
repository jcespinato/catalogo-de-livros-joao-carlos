package br.com.catalogodelivros;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.Normalizer;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String USER = "aluno@catalogo.local";
    private static final String PASS = "123456";
    private static final String STUDENT = "João Carlos de Souza Espinato";
    private static final int BLUE = Color.rgb(29, 61, 111);
    private static final int DARK = Color.rgb(35, 42, 52);
    private final NumberFormat money = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
    private final Book[] books = {
        new Book("Dom Casmurro", "Romance brasileiro", 29.90, 8),
        new Book("Memórias Póstumas de Brás Cubas", "Literatura brasileira", 34.50, 5),
        new Book("O Cortiço", "Realismo e sociedade", 25.00, 10),
        new Book("Iracema", "Romance histórico", 22.90, 4),
        new Book("A Moreninha", "Romance brasileiro", 27.00, 6)
    };
    private final int[] cart = new int[books.length];
    private String screen = "login";
    private boolean signedIn = false;
    private LinearLayout body;

    private static class Book {
        final String title, subject;
        final double price;
        int stock;
        Book(String title, String subject, double price, int stock) {
            this.title = title; this.subject = subject; this.price = price; this.stock = stock;
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        showLogin();
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + .5f); }

    private TextView label(String value, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(DARK);
        t.setPadding(0, dp(7), 0, dp(7));
        if (bold) t.setTypeface(null, 1);
        return t;
    }

    private Button button(String value, Runnable action) {
        Button b = new Button(this); b.setText(value); b.setAllCaps(false);
        b.setOnClickListener(v -> action.run());
        body.addView(b, new LinearLayout.LayoutParams(-1, -2));
        return b;
    }

    private void start(String title, String key) {
        screen = key;
        ScrollView scroll = new ScrollView(this);
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(20), dp(18), dp(20), dp(28));
        body.setBackgroundColor(Color.WHITE);
        scroll.addView(body);
        setContentView(scroll);
        TextView heading = label(title, 24, true);
        heading.setTextColor(BLUE);
        body.addView(heading);
        String timestamp = new SimpleDateFormat("dd/MM/yyyy HH:mm", new Locale("pt", "BR")).format(new Date());
        body.addView(label(STUDENT + "  •  " + timestamp, 12, false));
    }

    private void nav() {
        button("Catálogo", this::showCatalog);
        button("Carrinho (" + cartCount() + ")", this::showCart);
        button("Atendimento", this::showContact);
        button("Sobre o aplicativo", this::showAbout);
    }

    private void showLogin() {
        start("Catálogo de Livros", "login");
        body.addView(label("Acesso demonstrativo", 18, true));
        EditText email = new EditText(this);
        email.setSingleLine(true); email.setHint("E-mail");
        email.setInputType(33); body.addView(email);
        EditText password = new EditText(this);
        password.setSingleLine(true); password.setHint("Senha");
        password.setInputType(129); body.addView(password);
        body.addView(label("Teste: " + USER + " / " + PASS, 13, false));
        button("Entrar", () -> {
            if (USER.equalsIgnoreCase(email.getText().toString().trim())
                    && PASS.equals(password.getText().toString())) {
                signedIn = true; showCatalog();
            } else Toast.makeText(this, "E-mail ou senha incorretos", Toast.LENGTH_SHORT).show();
        });
        body.addView(label("Este acesso é local e serve apenas à demonstração acadêmica.", 13, false));
    }

    private String normalize(String text) {
        return Normalizer.normalize(text.toLowerCase(new Locale("pt", "BR")), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "");
    }

    private void showCatalog() {
        if (!signedIn) { showLogin(); return; }
        start("Catálogo de Livros", "catalog");
        body.addView(label("Procure pelo título ou assunto. Preços e estoque são demonstrativos.", 14, false));
        EditText search = new EditText(this); search.setSingleLine(true);
        search.setHint("Buscar livro ou assunto"); body.addView(search);
        LinearLayout results = new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL); body.addView(results);
        renderBooks(results, "");
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int c, int f) { }
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                renderBooks(results, s.toString());
            }
            public void afterTextChanged(Editable e) { }
        });
        nav();
    }

    private void renderBooks(LinearLayout results, String query) {
        results.removeAllViews(); int matches = 0;
        for (int i = 0; i < books.length; i++) {
            final int index = i; Book b = books[i];
            if (!normalize(b.title + " " + b.subject).contains(normalize(query))) continue;
            matches++;
            results.addView(label(b.title + "\n" + b.subject + "  •  " + money.format(b.price)
                    + "\nDisponível: " + (b.stock - cart[i]) + " de " + b.stock, 16, false));
            Button details = new Button(this); details.setText("Ver detalhes"); details.setAllCaps(false);
            details.setOnClickListener(v -> showDetails(index)); results.addView(details);
        }
        if (matches == 0) results.addView(label("Nenhum livro encontrado.", 15, false));
    }

    private void showDetails(int i) {
        Book b = books[i]; start("Detalhes do livro", "details");
        body.addView(label(b.title, 22, true));
        body.addView(label("Assunto: " + b.subject + "\nPreço: " + money.format(b.price)
                + "\nEstoque disponível: " + (b.stock - cart[i]), 17, false));
        button("Adicionar ao carrinho", () -> {
            if (cart[i] >= b.stock) {
                Toast.makeText(this, "Quantidade indisponível", Toast.LENGTH_SHORT).show(); return;
            }
            cart[i]++;
            Toast.makeText(this, "Livro adicionado", Toast.LENGTH_SHORT).show();
            showDetails(i);
        });
        button("Voltar ao catálogo", this::showCatalog);
        button("Abrir carrinho", this::showCart);
    }

    private int cartCount() { int total = 0; for (int n : cart) total += n; return total; }

    private void showCart() {
        start("Carrinho de compra", "cart");
        if (cartCount() == 0) body.addView(label("Seu carrinho está vazio.", 16, false));
        double total = 0;
        for (int i = 0; i < cart.length; i++) {
            if (cart[i] == 0) continue;
            final int index = i;
            Book b = books[i]; total += cart[i] * b.price;
            body.addView(label(b.title + "\n" + cart[i] + " × " + money.format(b.price)
                    + " = " + money.format(cart[i] * b.price), 16, false));
            button("Remover uma unidade de " + b.title, () -> { cart[index]--; showCart(); });
        }
        body.addView(label("Total: " + money.format(total), 20, true));
        if (cartCount() > 0) button("Finalizar simulação", () -> {
            for (int i = 0; i < cart.length; i++) { books[i].stock -= cart[i]; cart[i] = 0; }
            new AlertDialog.Builder(this).setTitle("Simulação concluída")
                    .setMessage("Estoque atualizado nesta sessão. Nenhum pagamento ou pedido real foi realizado.")
                    .setPositiveButton("Continuar", (d, w) -> showAbout()).show();
        });
        nav();
    }

    private void showContact() {
        start("Atendimento", "contact");
        body.addView(label("Escolha como compartilhar uma mensagem sobre o catálogo. O destinatário será escolhido no outro aplicativo.", 15, false));
        button("Enviar e-mail", () -> {
            Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
            intent.putExtra(Intent.EXTRA_SUBJECT, "Atendimento Catálogo de Livros");
            intent.putExtra(Intent.EXTRA_TEXT, "Olá, gostaria de informações sobre o catálogo de livros.");
            try { startActivity(intent); }
            catch (ActivityNotFoundException e) { Toast.makeText(this, "Nenhum aplicativo de e-mail encontrado", Toast.LENGTH_LONG).show(); }
        });
        button("Compartilhar pelo WhatsApp", () -> {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.setPackage("com.whatsapp");
            intent.putExtra(Intent.EXTRA_TEXT, "Olá, gostaria de informações sobre o catálogo de livros.");
            try { startActivity(intent); }
            catch (ActivityNotFoundException e) { Toast.makeText(this, "WhatsApp não instalado", Toast.LENGTH_LONG).show(); }
        });
        nav();
    }

    private void showAbout() {
        start("Sobre o aplicativo", "about");
        String about = "Catálogo de Livros • versão 1.0\n" +
                "Desenvolvido por " + STUDENT + ".\n" +
                "Aplicativo acadêmico de consulta de livros por título e assunto, com estoque, preço e carrinho demonstrativos. " +
                "O acesso é local; não há cobrança, pedido real ou envio de dados a servidor.";
        body.addView(label(about, 16, false));
        button("Ler aviso", () -> new AlertDialog.Builder(this)
                .setTitle("Aviso sobre o aplicativo").setMessage(about)
                .setPositiveButton("Fechar", null).show());
        nav();
        button("Sair da sessão", () -> { signedIn = false; showLogin(); });
    }

    @Override public void onBackPressed() {
        if ("login".equals(screen)) super.onBackPressed();
        else if ("catalog".equals(screen)) {
            new AlertDialog.Builder(this).setMessage("Encerrar a sessão?")
                    .setNegativeButton("Não", null)
                    .setPositiveButton("Sim", (d, w) -> { signedIn = false; showLogin(); }).show();
        } else showCatalog();
    }
}
